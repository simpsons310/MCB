var express = require('express');
var router = express.Router();
var mysql = require('mysql');

var con = mysql.createConnection({
	host: "localhost",
	user: "giang",
	password : "123456",
	database : "giang_db1"
});

var data = [];
con.connect();
router.get('/sensor1', function(req, res) {
  con.query("select * from sensor1 where id = (select max(id) from sensor1)", function (err, result, fields){
  	if (err) throw err;
  	con.query("select * from sensor1 where id = ((select max(id) from sensor1) - 1)", function (err, lastResult, fields){
  		if (err) throw err;
	  	con.query("select temp from sensor1 where temp = (select max(temp) from sensor1)", function (err, maxtemp, fields){
	  		if (err) throw err;	
	  		con.query("select temp from sensor1 where temp = (select min(temp) from sensor1)", function (err, mintemp, fields){
	  			if (err) throw err;
	  			con.query("select hum from sensor1 where hum = (select max(hum) from sensor1)", function (err, maxhum, fields){
	  				if (err) throw err;
	  				con.query("select hum from sensor1 where hum = (select min(hum) from sensor1)", function (err, minhum, fields){
	  					if (err) throw err;
	  					con.query("select dust from sensor1 where dust = (select max(dust) from sensor1)", function (err, maxdust, fields){
	  						if (err) throw err;
	  						con.query("select dust from sensor1 where dust = (select min(dust) from sensor1)", function (err, mindust, fields){
	  							if (err) throw err;
	  								con.query("select light from sensor1 where light = (select max(light) from sensor1)", function (err, maxlight, fields){
	  								if (err) throw err;
	  									con.query("select light from sensor1 where light = (select min(light) from sensor1)", function (err, minlight, fields){
	  									if (err) throw err;
	  										con.query("select AVG(temp) as avgtemp from sensor1", function (err, avgtemp, fields){
	  										if (err) throw err;
	  											con.query("select AVG(hum) as avghum from sensor1", function (err, avghum, fields){
	  											if (err) throw err;
	  												con.query("select AVG(dust) as avgdust from sensor1", function (err, avgdust, fields){
	  												if (err) throw err;
	  													con.query("select AVG(light) as avglight from sensor1", function (err, avglight, fields){
	  													if (err) throw err;
	  													var a = {result: result[0],  lastResult: lastResult[0],
		                                       		maxtemp: maxtemp[0], maxhum: maxhum[0], maxlight: maxlight[0], maxdust: maxdust[0],
		                                       		mintemp: mintemp[0], minhum: minhum[0], minlight: minlight[0], mindust: mindust[0],
		                                       		avgtemp: avgtemp[0], avghum: avghum[0], avglight: avglight[0], avgdust: avgdust[0]
		                                     		  };
		                              		res.json(a);
		                              		});
		                   					});
		                 					});
		               				});
		             				});
		           				});
		         			});
		       			});
		     			});
		   		});
		 		});
	  		});

		});
	});                                
});

router.post(`/led1`, function(req, res){
  con.query(`insert into led1(state,time) values(${req.body.signal},now())`, function (err, result, fields) {
      if (err) throw err;
      res.json({
      	message: "success",
      	data: result[0]
      });
  });
});

router.post(`/slide1`, function(req, res){
  con.query(`insert into slide1(state,time) values(${req.body.pwm},now())`, function (err, result, fields) {
      if (err) throw err;
      res.json({
        message: "success",
        data: result[0]
      });
  });
});

module.exports = router;
